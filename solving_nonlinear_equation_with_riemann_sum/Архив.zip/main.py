import matplotlib.pyplot as plt # для графика
import numpy as np # в данном коде тоже для графика


# из трех вариантов метода пряямоугольника, я буду использовать средний, потому что
# при прочих равных условиях он дает приближение точнее, чем левый и правый

def riemann_sum(func, a, b, num_of_partitions):
    # на вход принимает:
    # func - подынтегральную функцию
    # a - ниж предел интегрирования
    # b - верхний предел интегрирования
    # num_of_partitions - число разбиений

    step = (b - a) / num_of_partitions # определяем шаг

    x = a
    func_values = []

    for i in range(num_of_partitions):
        func_values.append(func(x + step/2))
        x = x + step

    return step * sum(func_values)

# чтение из файла - 3 примера
with open("input.txt", 'r') as f:
    a_file1 = int(next(f))
    b_file1 = int(next(f))
    x0_file1 = int(next(f))
    eps1 = float(next(f))

    line1 = f.readline() # pass the line

    a_file2 = int(next(f))
    b_file2 = int(next(f))
    x0_file2 = int(next(f))
    eps2 = float(next(f))

    line2 = f.readline() # pass the line

    a_file3 = int(next(f))
    b_file3 = int(next(f))
    x0_file3 = int(next(f))
    eps3 = float(next(f))


# здесь буду использовать пакет для многомерных вычислений numpy,
# потому что я не придумал(пока что) как без него начертить график

f = lambda x: np.sin(x) # сама функция

space = np.linspace(-10, 10, 100)
# чертим график
plt.plot(space, f(space), color='#fcba03')
plt.show()


# функция решения нелинейного уравнения

def solve_nonlinear_equation(a, x0, func, b, eps):
    # принимает на вход:
    # a - нижний предел интегрирования
    # x0 - начальное прилижение (наша догадка)
    # func - подыинтегральная функци
    # b - верхний предел интегрирования
    # n_iter - количество итерация

    x = x0
    prev = x0

    for i in range(100): # я думаю лимит в 100 итераций будет достаточно
        g = riemann_sum(func, a, x, 18) - b

        # если в какой-то точке функция обнуляется, то поднимаю исключение
        if func(x) == 0:
            raise Exception("it is impossible to converge\n")
        x = x - g / func(x)

        if abs(prev - x) < eps:
            break
        prev = x

    return x


sol1 = solve_nonlinear_equation(a_file1, x0_file1, f, b_file1, eps1)
sol2 = solve_nonlinear_equation(a_file2, x0_file2, f, b_file2, eps2)
sol3 = solve_nonlinear_equation(a_file3, x0_file3, f, b_file3, eps3)

print(sol1, " ", sol2 , " ", sol3)

# запись в файл и округление
with open('out.txt', 'w') as f:
    f.write(str(round(sol1, 4)) + "\n")
    f.write(str(round(sol2, 4)) + "\n")
    f.write(str(round(sol3, 4)) + "\n")

f.close()